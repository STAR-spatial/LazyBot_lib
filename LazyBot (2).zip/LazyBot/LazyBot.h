
float axe_y();

float axe_x();

float axe_z();

int Parchoc(int pin);

float Capteur_ultrasonic(int pin[]);

int Marche_avant(int pin[], int vitesse);

int Marche_arriere(int pin[], int vitesse);

int Tourner_gauche(int pin[], int vitesse);

int Tourner_droite(int pin[], int vitesse);

int Arret_Moteur(int pin[]);

