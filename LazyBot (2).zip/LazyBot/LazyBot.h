


float axe_y();

float axe_x();

float axe_z();

int Parchoc(int pin);

float Capteur_ultrasonic(int pin[]);